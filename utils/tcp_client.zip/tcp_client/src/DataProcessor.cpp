#include "DataProcessor.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <filesystem>
#include <cstring>

DataProcessor::DataProcessor(const std::string &saveDirectory)
    : saveDirectory_(saveDirectory), totalPackets_(0), validPackets_(0), crcErrors_(0)
{
    // 创建保存目录
    if (!createDirectory(saveDirectory_))
    {
        throw std::runtime_error("无法创建保存目录: " + saveDirectory_);
    }

    // 打开日志文件
    std::string logPath = saveDirectory_ + "/packet_log.txt";
    logFile_.open(logPath, std::ios::out | std::ios::app);
    if (!logFile_.is_open())
    {
        throw std::runtime_error("无法打开日志文件: " + logPath);
    }

    // 打开原始数据文件（二进制模式）
    std::string rawDataPath = saveDirectory_ + "/raw_data.bin";
    rawDataFile_.open(rawDataPath, std::ios::out | std::ios::binary | std::ios::app);
    if (!rawDataFile_.is_open())
    {
        throw std::runtime_error("无法打开原始数据文件: " + rawDataPath);
    }

    // 写入日志文件头
    auto now = std::chrono::system_clock::now();
    logFile_ << "\n=== 数据处理开始 " << formatTimestamp(now) << " ===" << std::endl;
    logFile_.flush();

    std::cout << "[DataProcessor] 初始化完成，数据保存到: " << saveDirectory_ << std::endl;
}

DataProcessor::~DataProcessor()
{
    // 写入统计信息
    if (logFile_.is_open())
    {
        auto now = std::chrono::system_clock::now();
        logFile_ << "\n=== 数据处理结束 " << formatTimestamp(now) << " ===" << std::endl;
        logFile_ << "总数据包数: " << totalPackets_ << std::endl;
        logFile_ << "有效数据包数: " << validPackets_ << std::endl;
        logFile_ << "CRC错误数据包数: " << crcErrors_ << std::endl;
        logFile_ << "数据包丢失率: " << std::fixed << std::setprecision(2)
                 << (totalPackets_ > 0 ? (double)(totalPackets_ - validPackets_) / totalPackets_ * 100 : 0)
                 << "%" << std::endl;
        logFile_.close();
    }

    if (rawDataFile_.is_open())
    {
        rawDataFile_.close();
    }

    std::cout << "[DataProcessor] 数据处理器已关闭，统计信息已保存" << std::endl;
}

void DataProcessor::processData(const uint8_t *data, size_t size)
{
    totalPackets_++;

    // 保存原始数据到二进制文件
    if (rawDataFile_.is_open())
    {
        // 写入数据包大小（4字节）
        uint32_t packetSize = static_cast<uint32_t>(size);
        rawDataFile_.write(reinterpret_cast<const char *>(&packetSize), sizeof(packetSize));
        // 写入数据内容
        rawDataFile_.write(reinterpret_cast<const char *>(data), size);
        rawDataFile_.flush();
    }

    // 检查是否为标准56字节数据包
    if (size == PACKET_SIZE)
    {
        DataPacket packet;
        if (parsePacket(data, packet))
        {
            if (verifyCRC(packet))
            {
                validPackets_++;
                savePacketToFile(packet);

                // 每100个有效包打印一次统计信息
                if (validPackets_ % 100 == 1)
                {
                    std::cout << "[DataProcessor] 有效数据包: " << validPackets_
                              << ", CRC错误: " << crcErrors_ << std::endl;
                }
            }
            else
            {
                crcErrors_++;
                std::cout << "[DataProcessor] CRC校验失败，数据包 #" << totalPackets_ << std::endl;
            }
        }
        else
        {
            std::cout << "[DataProcessor] 数据包格式错误，数据包 #" << totalPackets_ << std::endl;
        }
    }
    else
    {
        std::cout << "[DataProcessor] 非标准数据包大小: " << size << " 字节（期望 "
                  << PACKET_SIZE << " 字节）" << std::endl;
    }
}

bool DataProcessor::parsePacket(const uint8_t *data, DataPacket &packet)
{
    // 检查报头和报尾
    if (data[0] != HEADER_BYTE || data[PACKET_SIZE - 1] != FOOTER_BYTE)
    {
        return false;
    }

    // 解析数据包
    packet.header = data[0];
    packet.camera1_visible = data[1];
    packet.camera1_thermal = data[2];
    packet.camera2_visible = data[3];
    packet.camera2_thermal = data[4];

    // 复制CAN数据
    std::memcpy(packet.canData, &data[5], 48);

    // 解析CRC（小端序）
    packet.crc16 = data[53] | (data[54] << 8);
    packet.footer = data[55];

    // 记录时间戳
    packet.timestamp = std::chrono::system_clock::now();

    return true;
}

bool DataProcessor::verifyCRC(const DataPacket &packet)
{
    // 计算除CRC字段外的数据的CRC16
    uint8_t tempData[PACKET_SIZE - 3]; // 除去CRC(2字节)和报尾(1字节)
    tempData[0] = packet.header;
    tempData[1] = packet.camera1_visible;
    tempData[2] = packet.camera1_thermal;
    tempData[3] = packet.camera2_visible;
    tempData[4] = packet.camera2_thermal;
    std::memcpy(&tempData[5], packet.canData, 48);

    uint16_t calculatedCRC = calculateCRC16(tempData, sizeof(tempData));
    return calculatedCRC == packet.crc16;
}

uint16_t DataProcessor::calculateCRC16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0xFFFF; // 初始值

    for (size_t i = 0; i < length; ++i)
    {
        crc ^= data[i];
        for (int j = 0; j < 8; ++j)
        {
            if (crc & 0x0001)
                crc = (crc >> 1) ^ 0xA001; // 多项式 0xA001
            else
                crc >>= 1;
        }
    }

    return crc;
}

void DataProcessor::savePacketToFile(const DataPacket &packet)
{
    if (!logFile_.is_open())
        return;

    // 写入数据包信息到日志文件
    logFile_ << "\n--- 数据包 #" << validPackets_ << " ---" << std::endl;
    logFile_ << "时间戳: " << formatTimestamp(packet.timestamp) << std::endl;
    logFile_ << "报头: 0x" << std::hex << std::uppercase << (int)packet.header << std::dec << std::endl;
    logFile_ << "检测状态:" << std::endl;
    logFile_ << "  相机1可见光: " << (int)packet.camera1_visible << std::endl;
    logFile_ << "  相机1热成像: " << (int)packet.camera1_thermal << std::endl;
    logFile_ << "  相机2可见光: " << (int)packet.camera2_visible << std::endl;
    logFile_ << "  相机2热成像: " << (int)packet.camera2_thermal << std::endl;

    // 写入CAN数据的前8字节作为示例
    logFile_ << "CAN数据(前8字节): ";
    for (int i = 0; i < 8 && i < 48; ++i)
    {
        logFile_ << "0x" << std::hex << std::setfill('0') << std::setw(2)
                 << (int)packet.canData[i] << " ";
    }
    logFile_ << std::dec << std::endl;

    logFile_ << "CRC16: 0x" << std::hex << std::uppercase << packet.crc16 << std::dec << std::endl;
    logFile_ << "报尾: 0x" << std::hex << std::uppercase << (int)packet.footer << std::dec << std::endl;

    logFile_.flush();
}

bool DataProcessor::createDirectory(const std::string &directory)
{
    try
    {
        std::filesystem::create_directories(directory);
        return true;
    }
    catch (const std::filesystem::filesystem_error &e)
    {
        std::cout << "[DataProcessor] 创建目录失败: " << e.what() << std::endl;
        return false;
    }
}

std::string DataProcessor::formatTimestamp(const std::chrono::system_clock::time_point &timepoint)
{
    auto time_t = std::chrono::system_clock::to_time_t(timepoint);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                  timepoint.time_since_epoch()) %
              1000;

    std::tm tm;
    localtime_s(&tm, &time_t); // Windows安全版本

    std::stringstream ss;
    ss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    ss << "." << std::setfill('0') << std::setw(3) << ms.count();

    return ss.str();
}