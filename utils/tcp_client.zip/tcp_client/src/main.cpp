#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <atomic>
#include <csignal>
#include <iomanip>
#include <windows.h>
#include "TCPClient.h"
#include "DataProcessor.h"

// 全局变量，用于处理Ctrl+C信号
std::atomic<bool> g_running(true);

/**
 * @brief 信号处理函数，处理Ctrl+C退出
 * @param signal 信号类型
 */
void signalHandler(int signal)
{
    if (signal == SIGINT)
    {
        std::cout << "\n\n[主程序] 接收到退出信号，正在安全关闭..." << std::endl;
        g_running = false;
    }
}

/**
 * @brief 打印程序使用说明
 */
void printUsage()
{
    std::cout << "\n=== TCP数据接收客户端 ===" << std::endl;
    std::cout << "功能：连接到指定的TCP服务器，接收并保存数据包到本地文件" << std::endl;
    std::cout << "\n程序会自动：" << std::endl;
    std::cout << "1. 连接到服务器（支持自动重连）" << std::endl;
    std::cout << "2. 接收并解析56字节的数据包" << std::endl;
    std::cout << "3. 验证CRC16校验码" << std::endl;
    std::cout << "4. 保存数据到 received_data/ 目录" << std::endl;
    std::cout << "\n按 Ctrl+C 安全退出程序" << std::endl;
    std::cout << "================================\n"
              << std::endl;
}

/**
 * @brief 获取用户输入的服务器连接信息
 * @param serverIP 输出服务器IP地址
 * @param serverPort 输出服务器端口号
 */
void getUserInput(std::string &serverIP, int &serverPort)
{
    std::cout << "请输入服务器IP地址 (默认: 192.168.1.100): ";
    std::getline(std::cin, serverIP);
    if (serverIP.empty())
    {
        serverIP = "192.168.1.100";
    }

    std::string portStr;
    std::cout << "请输入服务器端口号 (默认: 12345): ";
    std::getline(std::cin, portStr);
    if (portStr.empty())
    {
        serverPort = 12345;
    }
    else
    {
        try
        {
            serverPort = std::stoi(portStr);
            if (serverPort <= 0 || serverPort > 65535)
            {
                std::cout << "端口号无效，使用默认值 12345" << std::endl;
                serverPort = 12345;
            }
        }
        catch (...)
        {
            std::cout << "端口号格式错误，使用默认值 12345" << std::endl;
            serverPort = 12345;
        }
    }

    std::cout << "\n连接目标: " << serverIP << ":" << serverPort << std::endl;
    std::cout << "数据保存目录: ./received_data/" << std::endl;
}

/**
 * @brief 打印连接状态和统计信息
 * @param client TCP客户端实例
 * @param processor 数据处理器实例
 */
void printStatus(const TCPClient &client, const DataProcessor &processor)
{
    static auto lastPrintTime = std::chrono::steady_clock::now();
    auto now = std::chrono::steady_clock::now();

    // 每5秒打印一次状态
    if (std::chrono::duration_cast<std::chrono::seconds>(now - lastPrintTime).count() >= 5)
    {
        std::cout << "\n--- 状态报告 ---" << std::endl;
        std::cout << "连接状态: " << (client.isConnected() ? "已连接" : "未连接") << std::endl;
        std::cout << "接收数据包总数: " << client.getPacketCount() << std::endl;
        std::cout << "处理数据包总数: " << processor.getTotalPackets() << std::endl;
        std::cout << "有效数据包数: " << processor.getValidPackets() << std::endl;
        std::cout << "CRC错误数据包数: " << processor.getCrcErrors() << std::endl;

        if (processor.getTotalPackets() > 0)
        {
            double successRate = (double)processor.getValidPackets() / processor.getTotalPackets() * 100;
            std::cout << "数据包成功率: " << std::fixed << std::setprecision(1)
                      << successRate << "%" << std::endl;
        }

        std::cout << "---------------\n"
                  << std::endl;
        lastPrintTime = now;
    }
}

int main()
{
    // 设置控制台标题
    SetConsoleTitle(L"TCP数据接收客户端");

    // 注册信号处理器
    std::signal(SIGINT, signalHandler);

    printUsage();

    try
    {
        // 获取用户输入
        std::string serverIP;
        int serverPort;
        getUserInput(serverIP, serverPort);

        // 创建数据处理器
        DataProcessor processor("received_data");

        // 创建数据接收回调函数
        auto dataCallback = [&processor](const uint8_t *data, size_t size)
        {
            processor.processData(data, size);
        };

        // 创建TCP客户端
        TCPClient client(serverIP, serverPort, dataCallback);

        // 启动客户端
        std::cout << "\n正在启动TCP客户端..." << std::endl;
        if (!client.start())
        {
            std::cerr << "启动TCP客户端失败" << std::endl;
            return 1;
        }

        std::cout << "TCP客户端已启动，开始尝试连接服务器..." << std::endl;
        std::cout << "程序正在运行中，按 Ctrl+C 退出\n"
                  << std::endl;

        // 主循环 - 监控状态并等待退出信号
        while (g_running)
        {
            printStatus(client, processor);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }

        // 优雅关闭
        std::cout << "\n正在关闭TCP客户端..." << std::endl;
        client.stop();

        // 打印最终统计信息
        std::cout << "\n=== 最终统计信息 ===" << std::endl;
        std::cout << "接收数据包总数: " << client.getPacketCount() << std::endl;
        std::cout << "处理数据包总数: " << processor.getTotalPackets() << std::endl;
        std::cout << "有效数据包数: " << processor.getValidPackets() << std::endl;
        std::cout << "CRC错误数据包数: " << processor.getCrcErrors() << std::endl;

        if (processor.getTotalPackets() > 0)
        {
            double successRate = (double)processor.getValidPackets() / processor.getTotalPackets() * 100;
            std::cout << "数据包成功率: " << std::fixed << std::setprecision(2)
                      << successRate << "%" << std::endl;
        }

        std::cout << "\n数据已保存到 received_data/ 目录" << std::endl;
        std::cout << "程序正常退出" << std::endl;
    }
    catch (const std::exception &e)
    {
        std::cerr << "程序错误: " << e.what() << std::endl;
        std::cout << "\n按任意键退出..." << std::endl;
        std::cin.get();
        return 1;
    }

    return 0;
}