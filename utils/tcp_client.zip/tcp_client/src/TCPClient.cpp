#include "TCPClient.h"
#include <iostream>
#include <chrono>
#include <thread>

#pragma comment(lib, "ws2_32.lib")

TCPClient::TCPClient(const std::string &serverIP, int serverPort, DataCallback callback)
    : clientSocket_(INVALID_SOCKET), serverIP_(serverIP), serverPort_(serverPort), isRunning_(false), isConnected_(false), dataCallback_(callback), packetCount_(0)
{
    // 初始化Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        throw std::runtime_error("Winsock初始化失败");
    }

    std::cout << "[TCPClient] 初始化完成，目标服务器: " << serverIP_ << ":" << serverPort_ << std::endl;
}

TCPClient::~TCPClient()
{
    stop();
    WSACleanup();
    std::cout << "[TCPClient] 客户端已关闭" << std::endl;
}

bool TCPClient::start()
{
    if (isRunning_)
    {
        std::cout << "[TCPClient] 客户端已在运行中" << std::endl;
        return true;
    }

    isRunning_ = true;
    clientThread_ = std::thread(&TCPClient::clientLoop, this);

    std::cout << "[TCPClient] 客户端已启动" << std::endl;
    return true;
}

void TCPClient::stop()
{
    if (!isRunning_)
        return;

    std::cout << "[TCPClient] 正在停止客户端..." << std::endl;
    isRunning_ = false;

    // 断开连接
    disconnect();

    // 等待线程结束
    if (clientThread_.joinable())
    {
        clientThread_.join();
    }

    std::cout << "[TCPClient] 客户端已停止" << std::endl;
}

bool TCPClient::isConnected() const
{
    return isConnected_;
}

size_t TCPClient::getPacketCount() const
{
    return packetCount_;
}

void TCPClient::clientLoop()
{
    uint8_t buffer[BUFFER_SIZE];

    while (isRunning_)
    {
        // 如果未连接，尝试连接
        if (!isConnected_)
        {
            if (connectToServer())
            {
                std::cout << "[TCPClient] 连接成功，开始接收数据..." << std::endl;
            }
            else
            {
                std::cout << "[TCPClient] 连接失败，" << RECONNECT_DELAY_MS / 1000 << "秒后重试..." << std::endl;
                std::this_thread::sleep_for(std::chrono::milliseconds(RECONNECT_DELAY_MS));
                continue;
            }
        }

        // 接收数据
        int bytesReceived = recv(clientSocket_, reinterpret_cast<char *>(buffer), BUFFER_SIZE, 0);

        if (bytesReceived > 0)
        {
            // 数据接收成功，调用回调函数处理
            packetCount_++;
            if (dataCallback_)
            {
                dataCallback_(buffer, bytesReceived);
            }

            // 打印接收状态（每10个包打印一次，避免刷屏）
            if (packetCount_ % 10 == 1)
            {
                std::cout << "[TCPClient] 已接收 " << packetCount_ << " 个数据包" << std::endl;
            }
        }
        else if (bytesReceived == 0)
        {
            // 服务器主动关闭连接
            std::cout << "[TCPClient] 服务器关闭了连接" << std::endl;
            disconnect();
        }
        else
        {
            // 接收数据出错
            int error = WSAGetLastError();
            std::cout << "[TCPClient] 接收数据失败，错误码: " << error << std::endl;
            disconnect();
        }
    }

    // 循环结束，确保断开连接
    disconnect();
}

bool TCPClient::connectToServer()
{
    // 创建套接字
    clientSocket_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSocket_ == INVALID_SOCKET)
    {
        std::cout << "[TCPClient] 创建套接字失败，错误码: " << WSAGetLastError() << std::endl;
        return false;
    }

    // 设置服务器地址
    sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPort_);

    // 将IP地址字符串转换为网络地址
    if (inet_pton(AF_INET, serverIP_.c_str(), &serverAddr.sin_addr) <= 0)
    {
        std::cout << "[TCPClient] 无效的IP地址: " << serverIP_ << std::endl;
        closesocket(clientSocket_);
        clientSocket_ = INVALID_SOCKET;
        return false;
    }

    // 连接到服务器
    if (connect(clientSocket_, reinterpret_cast<sockaddr *>(&serverAddr), sizeof(serverAddr)) == SOCKET_ERROR)
    {
        int error = WSAGetLastError();
        // 只在第一次连接失败时打印详细错误，避免重连时刷屏
        if (packetCount_ == 0)
        {
            std::cout << "[TCPClient] 连接服务器失败，错误码: " << error << std::endl;
        }
        closesocket(clientSocket_);
        clientSocket_ = INVALID_SOCKET;
        return false;
    }

    isConnected_ = true;
    return true;
}

void TCPClient::disconnect()
{
    if (clientSocket_ != INVALID_SOCKET)
    {
        closesocket(clientSocket_);
        clientSocket_ = INVALID_SOCKET;
    }
    isConnected_ = false;
}