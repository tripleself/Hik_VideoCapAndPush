#pragma once

#include <string>
#include <vector>
#include <functional>
#include <thread>
#include <atomic>
#include <winsock2.h>
#include <ws2tcpip.h>

/**
 * @brief TCP客户端类，负责连接服务器并接收数据
 *
 * 功能包括：
 * - 连接到指定的TCP服务器
 * - 持续接收数据并通过回调函数处理
 * - 自动重连机制
 * - 线程安全的启动和停止
 */
class TCPClient
{
public:
    /**
     * @brief 数据接收回调函数类型
     * @param data 接收到的数据
     * @param size 数据大小（字节）
     */
    using DataCallback = std::function<void(const uint8_t *data, size_t size)>;

    /**
     * @brief 构造函数
     * @param serverIP 服务器IP地址（如 "192.168.1.100"）
     * @param serverPort 服务器端口号（如 12345）
     * @param callback 数据接收回调函数
     */
    TCPClient(const std::string &serverIP, int serverPort, DataCallback callback);

    /**
     * @brief 析构函数，自动断开连接
     */
    ~TCPClient();

    /**
     * @brief 启动客户端，开始连接服务器
     * @return true 启动成功, false 启动失败
     */
    bool start();

    /**
     * @brief 停止客户端，断开连接
     */
    void stop();

    /**
     * @brief 检查是否已连接到服务器
     * @return true 已连接, false 未连接
     */
    bool isConnected() const;

    /**
     * @brief 获取接收到的数据包总数
     * @return 数据包数量
     */
    size_t getPacketCount() const;

private:
    /**
     * @brief 客户端主循环，处理连接和数据接收
     */
    void clientLoop();

    /**
     * @brief 连接到服务器
     * @return true 连接成功, false 连接失败
     */
    bool connectToServer();

    /**
     * @brief 断开与服务器的连接
     */
    void disconnect();

    // 网络相关
    SOCKET clientSocket_;  ///< 客户端套接字
    std::string serverIP_; ///< 服务器IP地址
    int serverPort_;       ///< 服务器端口号

    // 线程控制
    std::atomic<bool> isRunning_;   ///< 客户端运行状态
    std::atomic<bool> isConnected_; ///< 连接状态
    std::thread clientThread_;      ///< 客户端工作线程

    // 数据处理
    DataCallback dataCallback_;       ///< 数据接收回调函数
    std::atomic<size_t> packetCount_; ///< 接收到的数据包计数

    // 常量配置
    static const int BUFFER_SIZE = 1024;        ///< 接收缓冲区大小
    static const int RECONNECT_DELAY_MS = 3000; ///< 重连延迟（毫秒）
};