#pragma once

#include <string>
#include <fstream>
#include <memory>
#include <chrono>
#include <cstdint>

/**
 * @brief 数据处理器类，负责解析和保存接收到的数据
 *
 * 功能包括：
 * - 解析56字节的数据包格式
 * - 保存数据到本地文件
 * - 生成统计信息
 * - 数据包完整性验证
 */
class DataProcessor
{
public:
    /**
     * @brief 数据包结构体，用于解析56字节的数据包
     */
    struct DataPacket
    {
        uint8_t header;          ///< 报头 (0xAA)
        uint8_t camera1_visible; ///< 相机1可见光检测状态
        uint8_t camera1_thermal; ///< 相机1热成像检测状态
        uint8_t camera2_visible; ///< 相机2可见光检测状态
        uint8_t camera2_thermal; ///< 相机2热成像检测状态
        uint8_t canData[48];     ///< CAN数据负载
        uint16_t crc16;          ///< CRC16校验码
        uint8_t footer;          ///< 报尾 (0xFF)

        std::chrono::system_clock::time_point timestamp; ///< 接收时间戳
    };

    /**
     * @brief 构造函数
     * @param saveDirectory 数据保存目录路径
     */
    DataProcessor(const std::string &saveDirectory = "received_data");

    /**
     * @brief 析构函数，确保文件正确关闭
     */
    ~DataProcessor();

    /**
     * @brief 处理接收到的原始数据
     * @param data 原始数据指针
     * @param size 数据大小
     */
    void processData(const uint8_t *data, size_t size);

    /**
     * @brief 获取处理的数据包总数
     * @return 数据包总数
     */
    size_t getTotalPackets() const { return totalPackets_; }

    /**
     * @brief 获取有效数据包数量
     * @return 有效数据包数量
     */
    size_t getValidPackets() const { return validPackets_; }

    /**
     * @brief 获取CRC校验失败的数据包数量
     * @return CRC错误数据包数量
     */
    size_t getCrcErrors() const { return crcErrors_; }

private:
    /**
     * @brief 解析56字节数据包
     * @param data 数据指针
     * @param packet 输出的数据包结构
     * @return true 解析成功, false 解析失败
     */
    bool parsePacket(const uint8_t *data, DataPacket &packet);

    /**
     * @brief 验证数据包的CRC16校验码
     * @param packet 数据包结构
     * @return true 校验通过, false 校验失败
     */
    bool verifyCRC(const DataPacket &packet);

    /**
     * @brief 计算CRC16校验码
     * @param data 数据指针
     * @param length 数据长度
     * @return CRC16校验码
     */
    uint16_t calculateCRC16(const uint8_t *data, size_t length);

    /**
     * @brief 保存数据包到文件
     * @param packet 数据包结构
     */
    void savePacketToFile(const DataPacket &packet);

    /**
     * @brief 创建保存目录
     * @param directory 目录路径
     * @return true 创建成功, false 创建失败
     */
    bool createDirectory(const std::string &directory);

    /**
     * @brief 格式化时间戳为字符串
     * @param timepoint 时间点
     * @return 格式化的时间字符串
     */
    std::string formatTimestamp(const std::chrono::system_clock::time_point &timepoint);

    // 文件保存相关
    std::string saveDirectory_; ///< 数据保存目录
    std::ofstream logFile_;     ///< 日志文件流
    std::ofstream rawDataFile_; ///< 原始数据文件流

    // 统计信息
    size_t totalPackets_; ///< 总数据包数
    size_t validPackets_; ///< 有效数据包数
    size_t crcErrors_;    ///< CRC错误数据包数

    // 常量定义
    static const size_t PACKET_SIZE = 56;    ///< 标准数据包大小
    static const uint8_t HEADER_BYTE = 0xAA; ///< 标准报头字节
    static const uint8_t FOOTER_BYTE = 0xFF; ///< 标准报尾字节
};