@echo off
echo ====================================
echo      TCP客户端项目编译脚本
echo ====================================

:: 检查是否安装了CMake
where cmake >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo 错误: 未找到 cmake 命令，请先安装 CMake
    echo 下载地址: https://cmake.org/download/
    pause
    exit /b 1
)

:: 检查是否有C++编译器
where g++ >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    where cl >nul 2>nul
    if %ERRORLEVEL% NEQ 0 (
        echo 错误: 未找到C++编译器，请安装以下之一:
        echo 1. MinGW-w64 (推荐): https://www.mingw-w64.org/
        echo 2. Visual Studio Build Tools
        pause
        exit /b 1
    )
)

:: 创建构建目录
if not exist build (
    mkdir build
    echo 创建构建目录: build/
)

:: 进入构建目录并执行CMake
cd build

echo.
echo 正在配置项目...
cmake .. -G "MinGW Makefiles"
if %ERRORLEVEL% NEQ 0 (
    echo CMake配置失败
    cd ..
    pause
    exit /b 1
)

echo.
echo 正在编译项目...
cmake --build . --config Release
if %ERRORLEVEL% NEQ 0 (
    echo 编译失败
    cd ..
    pause
    exit /b 1
)

cd ..

echo.
echo ====================================
echo       编译成功！
echo ====================================
echo 可执行文件位置: build/bin/TCPClient.exe
echo.
echo 使用方法:
echo 1. 启动您的LocationReporter服务器
echo 2. 运行: build\bin\TCPClient.exe
echo 3. 按提示输入服务器IP和端口
echo.
echo 数据将保存到 received_data/ 目录
echo ====================================

pause 